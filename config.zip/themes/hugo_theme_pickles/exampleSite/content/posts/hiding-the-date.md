---
author: 'Dave Kerr'
date: 2020-06-11
linktitle: Hiding the Date
title: Hiding the Date
weight: 10
hideDate: true
tags: ['go', 'golang', 'hugo', 'development']
---

## Introduction

Hiding the date in a page or post is easy! Just set `hideDate` to `true` in your front matter.

As an example, the front matter for this page is:

```
---
date: 2020-06-11
linktitle: Hiding the Date
title: Hiding the Date
weight: 10
hideDate: true
---
```

Piece of cake!
