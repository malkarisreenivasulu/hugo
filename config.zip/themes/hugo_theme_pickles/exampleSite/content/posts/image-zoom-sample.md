---
author: 'Misumi Takuma'
date: 2017-04-01
linktitle: Image Zoom Sample
title: Image Zoom Sample
weight: 10
tags: ['go', 'golang', 'hugo', 'development']
---

This theme is magnified like the image of Medium.

The jQuery plugin called [Zoom.js](https://github.com/fat/zoom.js/) is used.

{{% zoom-img src="http://placekitten.com/g/640/340" %}}

{{% zoom-img src="/images/default.jpg" %}}

No Zoom.

![猫](http://placekitten.com/g/1000/700 'サンプル')
